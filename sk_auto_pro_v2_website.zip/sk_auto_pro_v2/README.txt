S.K. Auto CNG Cylinder Testing - Professional VK-style Static Website (v2)

Files included:
- index.html (Bootstrap 5 + AOS + Font Awesome)
- style.css (custom styles)
- script.js (counters, gallery lightbox, smooth scroll)
- images/hero.jpg (your provided image)
- images/gallery1.jpg..gallery4.jpg (generated thumbnails)
- images/service1.svg..service3.svg (service icons)

Important setup steps after download:
1. Replace the Formspree action URL in the contact form with your Formspree ID:
   action="https://formspree.io/f/your-form-id" -> use your real ID.
   Or replace the form with your backend endpoint.
2. Optionally replace gallery images and hero.jpg with your high-resolution photos.
3. Host anywhere (GitHub Pages, Netlify, Vercel, or any static host).

If you want, I can:
- Replace the Formspree form with a working backend (Node/Express) and deploy it.
- Customize fonts, add your logo, or prepare a WordPress theme version.
